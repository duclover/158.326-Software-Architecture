﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _19045672
{
    public class InClass : IAttendanceType
    {
        public string AttendanceType()
        {
            return "In-class";
        }
    }
}