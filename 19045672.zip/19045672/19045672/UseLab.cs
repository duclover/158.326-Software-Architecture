﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _19045672
{
    public class UseLab : ILabType
    {
        public string LabType()
        {
            return "Use the Massey Labs";
        }
    }
}