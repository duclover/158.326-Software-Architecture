﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tutorial6
{
    public enum EDuck
    {
        RedHeadDuck,
        RubberDuck,
        DecoyDuck,
        MallardDuck
    }
}