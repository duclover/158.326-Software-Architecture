﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tutorial6
{
    public class FlyWithWings : IFlyBehaviour
    {
        //public FlyWithWings()
        //{
        //    throw new System.NotImplementedException();
        //}

        public string Fly()
        {
            //throw new System.NotImplementedException();
            return "I can fly with my wings!";
        }
    }
}