﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tutorial6
{
    public class Squeak : IQuackBehaviour
    {
        //public Squeak()
        //{
        //    throw new System.NotImplementedException();
        //}

        public string Quack()
        {
            //throw new System.NotImplementedException();
            return "Squeak squeaks";
        }
    }
}