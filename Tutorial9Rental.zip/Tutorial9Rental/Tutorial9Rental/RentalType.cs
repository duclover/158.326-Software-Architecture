﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tutorial9Rental
{
    public enum RentalType
    {
        Hatchback = 50,
        Sedan = 80,
        Convertible = 100,
        Saloon = 120,
        None = 0
    }
}